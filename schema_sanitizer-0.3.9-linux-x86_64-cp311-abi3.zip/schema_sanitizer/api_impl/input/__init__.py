"""Public input preparation domain."""
