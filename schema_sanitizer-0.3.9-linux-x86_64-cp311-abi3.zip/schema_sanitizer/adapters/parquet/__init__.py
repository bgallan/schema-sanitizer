"""Public Parquet adapter package."""
