"""Focused PyArrow adapter implementations."""
